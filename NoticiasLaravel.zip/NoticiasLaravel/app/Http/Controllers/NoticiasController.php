<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App;

class NoticiasController extends Controller
{
    public function noticias(){
        $noticias = App\Noticias::paginate(10);
        $autores = App\Autores::all();
        $categorias = App\Categorias::all();
        return view('noticias', compact('noticias', 'autores', 'categorias'));
    }
    
        public function noticia($id){
        $noticia = App\Noticias::findOrFail($id);
        $autores = App\Autores::all();
        $categorias = App\Categorias::all();
        return view('noticia', compact('noticia', 'autores', 'categorias'));
    }
    
        public function autor($id){
        $autor = App\Autores::findOrFail($id);
        $autores = App\Autores::all();
        $noticias = App\Noticias::all();
        $categorias = App\Categorias::all();
        return view('autor', compact('autor', 'autores', 'noticias', 'categorias'));
    }
    
    public function categoria($id){
        $categoria = App\Categorias::findOrFail($id);
        $autores = App\Autores::all();
        $noticias = App\Noticias::paginate(15);
        $categorias = App\Categorias::all();
        return view('categoria', compact('categoria', 'autores', 'noticias', 'categorias'));
    }
}
