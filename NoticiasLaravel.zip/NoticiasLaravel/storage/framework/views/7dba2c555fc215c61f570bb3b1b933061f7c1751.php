<?php echo $__env->make('headerok', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    img {
        max-width: 300px;
    }
    h1 {
        text-align: center;
        margin-bottom: 2em;
    }

</style>
<main id="main">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8" style="display:inline">
            <h1>Escritas por <?php echo e($autor->Autor); ?></h1>
            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->id_autor == $autor->id_autor): ?>

            <div style="text-align:center">
                <img src="<?php echo e($item->Imagen); ?>">
                <h2><?php echo e($item->Titulo); ?></h2>
            </div>
            <p class="lead" style="text-align:justify"><?php echo e($item->Cabecera); ?></p>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($categoria->id_cat == $item->id_cat): ?>
            <p>Categoría: <?php echo e($categoria->Categoria); ?> || <?php echo e($item->Fecha); ?></p>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="lead" style="text-align:center">
                <a class="btn btn-primary btn-lg" href="<?php echo e(route('noticia', $item->id)); ?>" role="button">Leer Noticia <?php echo e($item->id); ?></a>
            </p>
            <hr class="my-4">

            <div class="col-sm-1"></div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NoticiasLaravel\resources\views/autor.blade.php ENDPATH**/ ?>