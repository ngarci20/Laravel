<?php echo $__env->make('headerok', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="main">
        <div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8" style="display:inline">
        <div style="text-align:center">
            <img src="<?php echo e($noticia->Imagen); ?>">
            <h2><?php echo e($noticia->Titulo); ?></h2>
        </div>
        <p class="lead" style="text-align:justify"><?php echo e($noticia->Contenido); ?></p>
        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($autor->id_autor == $noticia->id_autor): ?>
        <p><?php echo e($autor->Autor); ?> | <?php echo e($noticia->Fecha); ?></p>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-sm-1"></div>
    </div>
    </main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NoticiasLaravel\resources\views/noticia.blade.php ENDPATH**/ ?>