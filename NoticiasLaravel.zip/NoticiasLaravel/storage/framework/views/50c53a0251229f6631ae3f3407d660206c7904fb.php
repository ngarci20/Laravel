aaaaaaaaaaaaaa
<!--
<!DOCTYPE html>
<html>

<head>
    <title>Noticialia</title>
    <link rel="stylesheet" href="https://bootswatch.com/4/darkly/bootstrap.min.css">
    <link rel="stylesheet" href="./style.css">

    <style>
        h1.centrar {
            margin: 1em auto !important;
            text-align: center;
        }

        form,
        input {
            display: inline;
        }

        #categorias {
            margin-left: 10em;
        }


        #autores {
            margin-left: 20em;
        }

    </style>
</head>

<body>
-->
<!--

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary" id="nav">
        <a class="navbar-brand" href="#" home>Noticialia</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
-->
<!--                    <a class="nav-link" href="<?php echo e(route('noticias')); ?>" home>Inicio <span class="sr-only">(current)</span></a>-->
<!--
                </li>
                <li class="nav-item active" id="porcat">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Por Categoría <span class="caret"></span></a>

                </li>
                <li class="nav-item active" id="porautor">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Por Autor <span class="caret"></span></a>
                </li>
            </ul>
        </div>
-->
<!--
        <div class="dropdown-menu" id="categorias">
            <a class="dropdown-item" href="<?php echo e(route('categoria')); ?>">NombreCat</a>
        </div>


        <div class="dropdown-menu" id="autores">
            <a class="dropdown-item" href="<?php echo e(route('autor')); ?>">NombreAutor</a>
        </div>
-->
<!--    </nav>-->



<!--
    <script>
        window.onload = function() {
            document.getElementById('categorias').style.display = 'none';
            document.getElementById('autores').style.display = 'none';
        };

        document.getElementById('porcat').onclick = function() {
            document.getElementById('categorias').style.display = 'inline';
            document.getElementById('autores').style.display = 'none';
        };

        document.getElementById('porautor').onclick= function() {
            document.getElementById('autores').style.display = 'inline';
            document.getElementById('categorias').style.display = 'none';
        };
        
        document.getElementById('main').onclick= function() {
            document.getElementById('autores').style.display = 'none';
            document.getElementById('categorias').style.display = 'none';
        };
    </script>
-->
    <div class="jumbotron">
<?php /**PATH C:\xampp\htdocs\NoticiasLaravel\resources\views/cabecera.blade.php ENDPATH**/ ?>