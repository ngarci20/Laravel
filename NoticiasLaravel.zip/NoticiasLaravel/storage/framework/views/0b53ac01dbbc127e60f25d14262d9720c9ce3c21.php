<?php echo $__env->make('headerok', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    #paginado {
       position: relative;
       left: 27%;
    }
    .page-link {
        background-color: #375A7F;
    }
    .page-item.active .page-link {
        background-color: #222;
    }
    .page-item:hover .page-link {
        background-color: #303030;
    }

</style>
<main id="main">
    <div class="row">
        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-1"></div>
    <div class="col-sm-4" style="display:inline">
        <div style="text-align:center">
            <img src="<?php echo e($item->Imagen); ?>">
            <h2><?php echo e($item->Titulo); ?></h2>
        </div>
        <p class="lead" style="text-align:justify"><?php echo e($item->Cabecera); ?></p>
        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($autor->id_autor == $item->id_autor): ?>
        <p><?php echo e($autor->Autor); ?> | <?php echo e($item->Fecha); ?></p>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($categoria->id_cat == $item->id_cat): ?>
        <p>Categoría: <?php echo e($categoria->Categoria); ?></p>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p class="lead" style="text-align:center">
            <a class="btn btn-primary btn-lg" href="<?php echo e(route('noticia', $item->id)); ?>" role="button">Leer Noticia <?php echo e($item->id); ?></a>
        </p>
        <hr class="my-4">
    </div>
    <div class="col-sm-1"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div>
        <ul class="pagination pagination-lg" id="paginado">
            <?php echo e($noticias->links()); ?>

        </ul>
    </div>

</main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NoticiasLaravel\resources\views/noticias.blade.php ENDPATH**/ ?>