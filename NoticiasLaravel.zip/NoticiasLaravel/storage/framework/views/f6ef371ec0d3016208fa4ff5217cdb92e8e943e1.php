</div>
<div class="jumbotron">

</body>
</html>
<?php /**PATH C:\xampp\htdocs\NoticiasLaravel\resources\views/footer.blade.php ENDPATH**/ ?>