<?php

use Illuminate\Support\Facades\Route;

Route::get('/noticias', 'NoticiasController@noticias')->name('noticias');

Route::get('noticia/{id}', 'NoticiasController@noticia')->name('noticia');

Route::get('categoria/{id}', 'NoticiasController@categoria')->name('categoria');

Route::get('autor/{id}', 'NoticiasController@autor')->name('autor');





