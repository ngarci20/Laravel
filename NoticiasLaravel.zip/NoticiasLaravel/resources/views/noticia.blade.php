@include('headerok')
    <main id="main">
        <div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8" style="display:inline">
        <div style="text-align:center">
            <img src="{{$noticia->Imagen}}">
            <h2>{{$noticia->Titulo}}</h2>
        </div>
        <p class="lead" style="text-align:justify">{{$noticia->Contenido}}</p>
        @foreach ($autores as $autor)
        @if ($autor->id_autor == $noticia->id_autor)
        <p>{{$autor->Autor}} | {{$noticia->Fecha}}</p>
        @endif
        @endforeach
    </div>
    <div class="col-sm-1"></div>
    </div>
    </main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
@include('footer')
