@include('headerok')
<style>
    img {
        max-width: 300px;
    }
    h1 {
        text-align: center;
        margin-bottom: 2em;
    }

</style>
<main id="main">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8" style="display:inline">
            <h1>Escritas por {{$autor->Autor}}</h1>
            @foreach ($noticias as $item)
            @if ($item->id_autor == $autor->id_autor)

            <div style="text-align:center">
                <img src="{{$item->Imagen}}">
                <h2>{{$item->Titulo}}</h2>
            </div>
            <p class="lead" style="text-align:justify">{{$item->Cabecera}}</p>
            @foreach ($categorias as $categoria)
            @if ($categoria->id_cat == $item->id_cat)
            <p>Categoría: {{$categoria->Categoria}} || {{$item->Fecha}}</p>
            @endif
            @endforeach
            <p class="lead" style="text-align:center">
                <a class="btn btn-primary btn-lg" href="{{route('noticia', $item->id)}}" role="button">Leer Noticia {{$item->id}}</a>
            </p>
            <hr class="my-4">

            <div class="col-sm-1"></div>
            @endif
            @endforeach
        </div>
    </div>
</main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
@include('footer')
