@include('headerok')
<style>
    img {
        max-width: 300px;
    }
    h1 {
        text-align: center;
        margin-bottom: 2em;
    }
        #paginado {
       position: relative;
       left: 33%;
    }
    .page-link {
        background-color: #375A7F;
    }
    .page-item.active .page-link {
        background-color: #222;
    }
    .page-item:hover .page-link {
        background-color: #303030;
    }

</style>
<main id="main">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8" style="display:inline">
            <h1>Categoría {{$categoria->Categoria}}</h1>
            @foreach ($noticias as $item)
            @if ($item->id_cat == $categoria->id_cat)
            <div style="text-align:center">
                <img src="{{$item->Imagen}}">
                <h2>{{$item->Titulo}}</h2>
            </div>
            <p class="lead" style="text-align:justify">{{$item->Cabecera}}</p>
            @foreach ($autores as $auto)
            @if ($auto->id_autor == $item->id_autor)
            <p>{{$auto->Autor}} || {{$item->Fecha}}</p>
            @endif
            @endforeach
            <p class="lead" style="text-align:center">
                <a class="btn btn-primary btn-lg" href="{{route('noticia', $item->id)}}" role="button">Leer Noticia {{$item->id}}</a>
            </p>
            <hr class="my-4">
            <div class="col-sm-1"></div>
            @endif
            @endforeach
        </div>
    </div>
        <div>
        <ul class="pagination pagination-lg" id="paginado">
            {{$noticias->links()}}
        </ul>
    </div>
</main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
@include('footer')
