@include('headerok')
<style>
    #paginado {
       position: relative;
       left: 27%;
    }
    .page-link {
        background-color: #375A7F;
    }
    .page-item.active .page-link {
        background-color: #222;
    }
    .page-item:hover .page-link {
        background-color: #303030;
    }

</style>
<main id="main">
    <div class="row">
        @foreach ($noticias as $item)
    <div class="col-sm-1"></div>
    <div class="col-sm-4" style="display:inline">
        <div style="text-align:center">
            <img src="{{$item->Imagen}}">
            <h2>{{$item->Titulo}}</h2>
        </div>
        <p class="lead" style="text-align:justify">{{$item->Cabecera}}</p>
        @foreach ($autores as $autor)
        @if ($autor->id_autor == $item->id_autor)
        <p>{{$autor->Autor}} | {{$item->Fecha}}</p>
        @endif
        @endforeach
        @foreach ($categorias as $categoria)
        @if ($categoria->id_cat == $item->id_cat)
        <p>Categoría: {{$categoria->Categoria}}</p>
        @endif
        @endforeach
        <p class="lead" style="text-align:center">
            <a class="btn btn-primary btn-lg" href="{{route('noticia', $item->id)}}" role="button">Leer Noticia {{$item->id}}</a>
        </p>
        <hr class="my-4">
    </div>
    <div class="col-sm-1"></div>
    @endforeach
    </div>

    <div>
        <ul class="pagination pagination-lg" id="paginado">
            {{$noticias->links()}}
        </ul>
    </div>

</main>
<script>
    document.getElementById('main').onclick = function() {
        document.getElementById('autores').style.display = 'none';
        document.getElementById('categorias').style.display = 'none';
    };

</script>
@include('footer')
