<!DOCTYPE html>
<html>

<head>
    <title>Noticialia</title>
    <link rel="stylesheet" href="https://bootswatch.com/4/darkly/bootstrap.min.css">

    <style>
        h1.centrar {
            margin: 1em auto !important;
            text-align: center;
        }

        form,
        input {
            display: inline;
        }
        
        img {
            text-align: center;
            width: 60%;
            margin-bottom: 1em;
        }

        #categorias {
            margin-left: 10em;
        }


        #autores {
            margin-left: 20em;
        }
        #main {
            margin: 2em auto;
        }

    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary" id="nav">
        <a class="navbar-brand" href="{{route('noticias')}}" home>Noticialia</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                </li>
                <li class="nav-item active" id="porcat">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Por Categoría <span class="caret"></span></a>

                </li>
                <li class="nav-item active" id="porautor">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Por Autor <span class="caret"></span></a>
                </li>
            </ul>
        </div>
        <div class="dropdown-menu" id="categorias">
            @foreach ($categorias as $item)
            <a class="dropdown-item" href="{{route('categoria', $item->id_cat)}}">{{$item->Categoria}}</a>
            @endforeach()
        </div>
        <div class="dropdown-menu" id="autores">
            @foreach ($autores as $item)
            <a class="dropdown-item" href="{{route('autor', $item->id_autor)}}">{{$item->Autor}}</a>
            @endforeach()
        </div>
    </nav>

    <script>
            window.onload = function() {
            document.getElementById('categorias').style.display = 'none';
            document.getElementById('autores').style.display = 'none';
        };

        document.getElementById('porcat').onclick = function() {
            document.getElementById('categorias').style.display = 'inline';
            document.getElementById('autores').style.display = 'none';
        };

        document.getElementById('porautor').onclick = function() {
            document.getElementById('autores').style.display = 'inline';
            document.getElementById('categorias').style.display = 'none';
        };

    </script>

