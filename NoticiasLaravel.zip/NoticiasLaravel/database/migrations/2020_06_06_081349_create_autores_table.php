<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAutoresTable extends Migration
{

    public function up()
    {
        Schema::create('autores', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('id_autor');
            $table->char('Autor');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('autores');
    }
}
