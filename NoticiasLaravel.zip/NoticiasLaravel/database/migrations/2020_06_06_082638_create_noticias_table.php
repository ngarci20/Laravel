<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNoticiasTable extends Migration
{

    public function up()
    {
        Schema::create('noticias', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('id');
            $table->foreignId('id_cat')->references('id_cat')->on('categorias');
            $table->foreignId('id_autor')->references('id_autor')->on('autores');
            $table->char('Titulo', 255);
            $table->date('Fecha');
            $table->text('Cabecera');
            $table->text('Contenido');
            $table->text('Imagen');
        });
    }

    public function down()
    {
        Schema::dropIfExists('noticias');
    }
}
