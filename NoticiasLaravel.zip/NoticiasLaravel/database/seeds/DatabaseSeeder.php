<?php

use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder
{

    public function run()
    {
        $this->call(AutoresTableSeeder::class);
        $this->call(CategoriasTableSeeder::class);
        $this->call(NoticiasTableSeeder::class);
    }
}
