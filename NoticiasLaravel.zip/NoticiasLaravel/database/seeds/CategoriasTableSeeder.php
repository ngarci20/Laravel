<?php

use Illuminate\Database\Seeder;

class CategoriasTableSeeder extends Seeder
{

    public function run()
    {
        factory(App\Categorias::class, 5)->create();
    }
}
