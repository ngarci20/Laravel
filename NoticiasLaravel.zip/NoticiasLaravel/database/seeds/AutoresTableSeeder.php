<?php

use Illuminate\Database\Seeder;

class AutoresTableSeeder extends Seeder
{

    public function run()
    {
        factory(App\Autores::class, 20)->create();
    }
}
