<?php

use Illuminate\Database\Seeder;


class NoticiasTableSeeder extends Seeder
{

    public function run()
    {
        factory(App\Noticias::class, 100)->create();
    }
}
