<?php

use Faker\Generator as Faker;

$factory->define(App\Autores::class, function (Faker $faker) {
    return [
       'Autor'=> $faker->name(20),
    ];
});
