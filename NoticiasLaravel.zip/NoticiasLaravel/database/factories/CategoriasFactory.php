<?php

use Faker\Generator as Faker;

$factory->define(App\Categorias::class, function (Faker $faker) {
    $title = $faker->unique()->word(8);
    return [
       'Categoria'=>$title,
    ];
});
