<?php

use Faker\Generator as Faker;

$factory->define(App\Noticias::class, function (Faker $faker) {
    $title = $faker->sentence(6);
    $faker->addProvider(new \Mmo\Faker\PicsumProvider($faker)); 
    return [
       'id_cat'=> rand(1,5),
       'id_autor'=> rand(1,20),
       'Titulo'=> $title,
       'Fecha'=>$faker->date($format = 'Y-m-d', $max = 'now'),
       'Cabecera'=>$faker->sentence(30),
       'Contenido'=>$faker->text($maxNbChars = 1800),
       //'Imagen'=>$faker->imageUrl($width = 640, $height = 480),        
       'Imagen' => $faker->picsumUrl(),

    ];
});
